
using System;
using System.Threading.Tasks;
using System.Windows.Forms;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();

        // Run updater silently
        Task.Run(async () => await Updater.CheckForUpdates());

        Application.Run(new Launcher());
    }
}
