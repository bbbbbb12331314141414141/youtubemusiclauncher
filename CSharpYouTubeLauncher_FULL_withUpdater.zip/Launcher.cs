
using System;
using System.Windows.Forms;

public partial class Launcher : Form
{
    private const string YTM_URL = "https://music.youtube.com/";
    private const string YT_URL  = "https://www.youtube.com/";

    public Launcher()
    {
        InitializeComponent();
    }

    private void btnMusic_Click(object sender, EventArgs e)
    {
        var window = new BrowserWindow(YTM_URL);
        window.Show();
        this.Hide();
    }

    private void btnYouTube_Click(object sender, EventArgs e)
    {
        var window = new BrowserWindow(YT_URL);
        window.Show();
        this.Hide();
    }
}
