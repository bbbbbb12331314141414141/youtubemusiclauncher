
using Microsoft.Web.WebView2.WinForms;
using System;
using System.IO;
using System.Windows.Forms;

public partial class BrowserWindow : Form
{
    private string Url;

    public BrowserWindow(string url)
    {
        Url = url;
        InitializeComponent();
        webView.Source = new Uri(url);
    }

    private void btnImport_Click(object sender, EventArgs e)
    {
        var dialog = new OpenFileDialog();
        dialog.Filter = "Encrypted Files (*.enc)|*.enc";

        if (dialog.ShowDialog() != DialogResult.OK)
            return;

        try
        {
            byte[] encrypted = File.ReadAllBytes(dialog.FileName);
            string json = Crypto.Decrypt(encrypted, UserData.Key);
            UserData.Data = System.Text.Json.JsonSerializer
                                .Deserialize<Dictionary<string, object>>(json);
            UserData.Save();

            MessageBox.Show("User data imported.");
        }
        catch
        {
            MessageBox.Show("Invalid or corrupted file.");
        }
    }

    private void btnExport_Click(object sender, EventArgs e)
    {
        if (!File.Exists(UserData.DataFile))
        {
            MessageBox.Show("No user data to export.");
            return;
        }

        var dialog = new SaveFileDialog();
        dialog.Filter = "Encrypted Files (*.enc)|*.enc";
        dialog.FileName = "userdata.enc";

        if (dialog.ShowDialog() != DialogResult.OK)
            return;

        File.Copy(UserData.DataFile, dialog.FileName, true);
        MessageBox.Show("User data exported.");
    }
}
