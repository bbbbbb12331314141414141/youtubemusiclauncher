
using Microsoft.Web.WebView2.WinForms;
using System.Windows.Forms;

public partial class BrowserWindow
{
    private WebView2 webView;
    private Button btnImport;
    private Button btnExport;

    private void InitializeComponent()
    {
        this.webView = new WebView2();
        this.btnImport = new Button();
        this.btnExport = new Button();
        this.SuspendLayout();

        this.webView.Dock = DockStyle.Fill;

        this.btnImport.Text = "Import User Data";
        this.btnImport.Dock = DockStyle.Bottom;
        this.btnImport.Height = 40;
        this.btnImport.Click += btnImport_Click;

        this.btnExport.Text = "Export User Data";
        this.btnExport.Dock = DockStyle.Bottom;
        this.btnExport.Height = 40;
        this.btnExport.Click += btnExport_Click;

        this.Text = "YouTube Launcher";
        this.WindowState = FormWindowState.Maximized;
        this.Controls.Add(this.webView);
        this.Controls.Add(this.btnExport);
        this.Controls.Add(this.btnImport);

        this.ResumeLayout(false);
    }
}
