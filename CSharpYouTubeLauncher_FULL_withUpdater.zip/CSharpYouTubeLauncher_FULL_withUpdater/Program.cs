using System;
using System.Threading.Tasks;
using System.Windows.Forms;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        // Run updater silently in background
        _ = Task.Run(async () => await Updater.CheckForUpdates());

        Application.Run(new Launcher());
    }
}