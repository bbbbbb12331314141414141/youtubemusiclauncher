
using System;
using System.IO;
using System.Text.Json;
using System.Collections.Generic;

public static class UserData
{
    public const string DataFile = "userdata.enc";
    public static byte[] Key = Crypto.LoadKey();

    public static Dictionary<string, object> Data =
        LoadUserData();

    public static void Save()
    {
        var json = JsonSerializer.Serialize(Data);
        var encrypted = Crypto.Encrypt(json, Key);
        File.WriteAllBytes(DataFile, encrypted);
    }

    public static Dictionary<string, object> LoadUserData()
    {
        try
        {
            if (!File.Exists(DataFile))
                return new();

            var encrypted = File.ReadAllBytes(DataFile);
            var json = Crypto.Decrypt(encrypted, Key);
            return JsonSerializer.Deserialize<Dictionary<string, object>>(json);
        }
        catch
        {
            return new();
        }
    }
}
