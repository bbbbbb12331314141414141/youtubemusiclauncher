
using System;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Diagnostics;
using System.Threading.Tasks;

public static class Updater
{
    private static readonly string UpdateUrl = "https://example.com/update.json"; 
    private static readonly string AppExe = "YouTubeLauncher.exe";

    public static async Task CheckForUpdates()
    {
        try
        {
            using var client = new HttpClient();
            var json = await client.GetStringAsync(UpdateUrl);

            var info = JsonSerializer.Deserialize<UpdateInfo>(json);
            if (info == null) return;

            var localVersion = typeof(Updater).Assembly.GetName().Version.ToString();

            if (info.version != localVersion)
            {
                string tempExe = "update.tmp";
                var bytes = await client.GetByteArrayAsync(info.download);

                File.WriteAllBytes(tempExe, bytes);

                Process.Start(new ProcessStartInfo
                {
                    FileName = tempExe,
                    Arguments = "--replace",
                    UseShellExecute = true
                });

                Environment.Exit(0);
            }
        }
        catch { }
    }

    public class UpdateInfo
    {
        public string version { get; set; }
        public string download { get; set; }
    }
}
