
using System.Windows.Forms;

public partial class Launcher
{
    private Button btnMusic;
    private Button btnYouTube;

    private void InitializeComponent()
    {
        this.btnMusic = new Button();
        this.btnYouTube = new Button();
        this.SuspendLayout();

        this.btnMusic.Text = "Open YouTube Music";
        this.btnMusic.Height = 60;
        this.btnMusic.Dock = DockStyle.Top;
        this.btnMusic.Click += btnMusic_Click;

        this.btnYouTube.Text = "Open YouTube";
        this.btnYouTube.Height = 60;
        this.btnYouTube.Dock = DockStyle.Top;
        this.btnYouTube.Click += btnYouTube_Click;

        this.ClientSize = new System.Drawing.Size(400, 200);
        this.Controls.Add(this.btnYouTube);
        this.Controls.Add(this.btnMusic);
        this.Text = "YouTube Launcher";

        this.ResumeLayout(false);
    }
}
