using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

public static class Crypto
{
    private const string KeyFile = "key.key";

    public static byte[] LoadKey()
    {
        if (!File.Exists(KeyFile))
            return GenerateKey();

        return File.ReadAllBytes(KeyFile);
    }

    public static byte[] GenerateKey()
    {
        using (var aes = Aes.Create())
        {
            aes.KeySize = 256;
            aes.GenerateKey();
            File.WriteAllBytes(KeyFile, aes.Key);
            return aes.Key;
        }
    }

    public static byte[] Encrypt(string json, byte[] key)
    {
        using var aes = Aes.Create();
        aes.Key = key;
        aes.GenerateIV();

        using var ms = new MemoryStream();
        ms.Write(aes.IV, 0, aes.IV.Length);
        using var cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write);
        using (var writer = new StreamWriter(cs))
            writer.Write(json);

        return ms.ToArray();
    }

    public static string Decrypt(byte[] data, byte[] key)
    {
        using var aes = Aes.Create();
        aes.Key = key;

        byte[] iv = new byte[16];
        Array.Copy(data, iv, 16);

        aes.IV = iv;

        using var ms = new MemoryStream(data, 16, data.Length - 16);
        using var cs = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read);
        using var reader = new StreamReader(cs);
        return reader.ReadToEnd();
    }
}
